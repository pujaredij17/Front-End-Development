function increaseValue() {
  var value = parseInt(document.getElementById('cart_number').value, 10);
  value = isNaN(value) ? 0 : value;
  value++;
  value > 10 ? value = 10 : '';
  document.getElementById('cart_number').value = value;
}

function decreaseValue() {
  var value = parseInt(document.getElementById('cart_number').value, 10);
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('cart_number').value = value;
}

function myFunction() {
  var nombre, text;
  var apellido;
  var correo;
  var tema;
  var alphaExp = /^[a-zA-Z]+$/;
  var emailExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

  // Get the value of the input field with id="numb"
  nombre = document.getElementById("usr").value;
  apellido = document.getElementById("lname").value;
  correo = document.getElementById("email").value;
  tema =  document.getElementById("topic").value;

 if (nombre !== "" && nombre.length <= 32 && nombre.match(alphaExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter a valid firstname for eg. Bob";
    }
document.getElementById("error_usr").innerHTML = text;


if (apellido !== "" && apellido.length <= 32 && apellido.match(alphaExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter a valid lastname for eg. Williams";
    }
document.getElementById("error_lname").innerHTML = text;
  

if (correo !== "" && correo.length <= 32 && correo.match(emailExp)) {
        text = "";
        } 
        else {
    text = "Please enter a valid email address for eg. somebody@example.com";
    }
document.getElementById("error_email").innerHTML = text;

if (tema !== "" && tema.length <= 32) {
        text = "";
        } 
        else {
    text = "This field is required";
    }
document.getElementById("error_topic").innerHTML = text;
} 

function myLogin() {
  var usuario;
  var contrasena;
  var emailExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  var alphaExp = /^[0-9a-zA-Z]+$/;
  var pwdExp = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,16}$/;


  usuario = document.getElementById("username").value;
  contrasena = document.getElementById("login_pwd").value;

  if (usuario !== "" && usuario.length >= 8 && usuario.length <=16 && usuario.match(alphaExp) || usuario !== "" && usuario.length <= 64 && usuario.match(emailExp)) {
        text = "";
        } 
        else {
    text = "Please enter valid username or registered email address";
    }
document.getElementById("error_username").innerHTML = text;

if (contrasena !== "" && contrasena.match(pwdExp)) {
        text = "";
        } 
        else {
    text = "Your password needs to be between 8 and 30 characters long, and contain one uppercase letter, one symbol, and a number";
    }
document.getElementById("error_pwd").innerHTML = text;
}

function resetPwd() {

  var correo;
  var emailExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

 correo = document.getElementById("reset_pwd").value;

 if (correo !=="" && correo.match(emailExp)){
  text = "";
}
  else{
    text ="Please enter your registered email address";
  }
  document.getElementById("error_reset").innerHTML = text;

}

function myRegister() {
  var reg_correo;
  var reg_nombre;
  var reg_contrasena;
  var reg_apellido;
  var reg_address;
  var reg_city;
  var reg_state;
  var reg_postal;
  var emailExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  var alphaExp1 = /^[A-Za-z ]+$/;
  var pwdExp = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
  var addressExp = /^[a-zA-Z0-9\s,'-]*$/;
  var cityExp = /^([a-zA-Z\u0080-\u024F]+(?:. |-| |'))*[a-zA-Z\u0080-\u024F]*$/;
  var numericExpression = /^\d{5}(?:[-\s]\d{4})?$/;




  reg_nombre = document.getElementById("Nombre_reg").value;
  reg_correo = document.getElementById("email_reg").value;
  reg_contrasena=document.getElementById("pwd_reg").value;
  reg_apellido= document.getElementById("Apellido_reg").value;
  reg_address=document.getElementById("dirección").value;
  reg_city=document.getElementById("Ciulad").value;
  reg_state=document.getElementById("estado_reg").value;
  reg_postal=document.getElementById("postal").value;


  if (reg_correo !== "" && reg_correo.length <= 64 && reg_correo.match(emailExp)) {
        text = "";
        } 
        else {
    text = "Please enter a valid email address for eg. somebody@example.com";
    }
document.getElementById("error_email_reg").innerHTML = text;


if (reg_nombre !== "" && reg_nombre.length <= 32 && reg_nombre.match(alphaExp1)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid firstname for eg. Bob";
    }
document.getElementById("error_fname_reg").innerHTML = text;

if (reg_contrasena !== "" && reg_contrasena.match(pwdExp)) {
        text = "";
        } 
        else {
    text = "Your password needs to be between 8 and 30 characters long, and contain one uppercase letter, one symbol, and a number";
    }
document.getElementById("error_pwd_reg").innerHTML = text;


if (reg_apellido !== "" && reg_apellido.length <= 32 && reg_apellido.match(alphaExp1)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid lastname for eg. Williams";
    }
document.getElementById("error_lname_reg").innerHTML = text;

if (reg_address !== "" && reg_address.length <= 32 && reg_address.match(addressExp)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid address";
    }
document.getElementById("error_address").innerHTML = text;

if (reg_city !== "" && reg_city.length <= 16 && reg_city.match(cityExp)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid city for eg. Arlington";
    }
document.getElementById("error_city").innerHTML = text;

if (reg_state !== "Select State"){
        text = "";
        } 
        
else {
    text = "Please Select any one option eg. Texas";
    }
document.getElementById("error_state_reg").innerHTML = text;

if (reg_postal !== "" && reg_postal.match(numericExpression)){
        text = "";
        } 
        
else {
    text = "Please enter a valid zip code eg. 76010";
    }
document.getElementById("error_postal").innerHTML = text;
}

function myRegister1() {
  var reg_correo;
  var reg_nombre;
  var reg_contrasena;
  var reg_apellido;
  var reg_address;
  var reg_city;
  var reg_state;
  var reg_postal;
  var emailExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  var alphaExp1 = /^[A-Za-z ]+$/;
  var pwdExp = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
  var addressExp = /^[a-zA-Z0-9\s,'-]*$/;
  var cityExp = /^([a-zA-Z\u0080-\u024F]+(?:. |-| |'))*[a-zA-Z\u0080-\u024F]*$/;
  var numericExpression = /^\d{5}(?:[-\s]\d{4})?$/;




  reg_nombre = document.getElementById("Nombre_reg1").value;
  reg_correo = document.getElementById("email_reg1").value;
  reg_contrasena=document.getElementById("pwd_reg1").value;
  reg_apellido= document.getElementById("Apellido_reg1").value;
  reg_address=document.getElementById("dirección1").value;
  reg_city=document.getElementById("Ciulad1").value;
  reg_state=document.getElementById("estado_reg1").value;
  reg_postal=document.getElementById("postal1").value;


  if (reg_correo !== "" && reg_correo.length <= 64 && reg_correo.match(emailExp)) {
        text = "";
        } 
        else {
    text = "Please enter a valid email address for eg. somebody@example.com";
    }
document.getElementById("error_email_reg1").innerHTML = text;


if (reg_nombre !== "" && reg_nombre.length <= 32 && reg_nombre.match(alphaExp1)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid firstname for eg. Bob";
    }
document.getElementById("error_fname_reg1").innerHTML = text;

if (reg_contrasena !== "" && reg_contrasena.match(pwdExp)) {
        text = "";
        } 
        else {
    text = "Your password needs to be between 8 and 30 characters long, and contain one uppercase letter, one symbol, and a number";
    }
document.getElementById("error_pwd_reg1").innerHTML = text;


if (reg_apellido !== "" && reg_apellido.length <= 32 && reg_apellido.match(alphaExp1)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid lastname for eg. Williams";
    }
document.getElementById("error_lname_reg1").innerHTML = text;

if (reg_address !== "" && reg_address.length <= 32 && reg_address.match(addressExp)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid address";
    }
document.getElementById("error_address1").innerHTML = text;

if (reg_city !== "" && reg_city.length <= 16 && reg_city.match(cityExp)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid city for eg. Arlington";
    }
document.getElementById("error_city1").innerHTML = text;

if (reg_state !== "Select State"){
        text = "";
        } 
        
else {
    text = "Please Select any one option eg. Texas";
    }
document.getElementById("error_state_reg1").innerHTML = text;

if (reg_postal !== "" && reg_postal.match(numericExpression)){
        text = "";
        } 
        
else {
    text = "Please enter a valid zip code eg. 76010";
    }
document.getElementById("error_postal1").innerHTML = text;
}

function myRegister2() {
  var reg_correo;
  var reg_nombre;
  var reg_contrasena;
  var reg_apellido;
  var reg_address;
  var reg_city;
  var reg_state;
  var reg_postal;
  var reg_radio;
  var emailExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  var alphaExp1 = /^[A-Za-z ]+$/;
  var pwdExp = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
  var addressExp = /^[a-zA-Z0-9\s,'-]*$/;
  var cityExp = /^([a-zA-Z\u0080-\u024F]+(?:. |-| |'))*[a-zA-Z\u0080-\u024F]*$/;
  var numericExpression = /^\d{5}(?:[-\s]\d{4})?$/;




  reg_nombre = document.getElementById("Nombre_reg2").value;
  reg_correo = document.getElementById("email_reg2").value;
  reg_contrasena=document.getElementById("pwd_reg2").value;
  reg_apellido= document.getElementById("Apellido_reg2").value;
  reg_address=document.getElementById("dirección2").value;
  reg_city=document.getElementById("Ciulad2").value;
  reg_state=document.getElementById("estado_reg2").value;
  reg_postal=document.getElementById("postal2").value;
  reg_radio=document.getElementsByName("Tipo de negodo 1").value;


  if (reg_correo !== "" && reg_correo.length <= 64 && reg_correo.match(emailExp)) {
        text = "";
        } 
        else {
    text = "Please enter a valid email address for eg. somebody@example.com";
    }
document.getElementById("error_email_reg2").innerHTML = text;


if (reg_nombre !== "" && reg_nombre.length <= 32 && reg_nombre.match(alphaExp1)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid firstname for eg. Bob";
    }
document.getElementById("error_fname_reg2").innerHTML = text;

if (reg_contrasena !== "" && reg_contrasena.match(pwdExp)) {
        text = "";
        } 
        else {
    text = "Your password needs to be between 8 and 30 characters long, and contain one uppercase letter, one symbol, and a number";
    }
document.getElementById("error_pwd_reg2").innerHTML = text;


if (reg_apellido !== "" && reg_apellido.length <= 32 && reg_apellido.match(alphaExp1)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid lastname for eg. Williams";
    }
document.getElementById("error_lname_reg2").innerHTML = text;

if (reg_address !== "" && reg_address.length <= 32 && reg_address.match(addressExp)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid address";
    }
document.getElementById("error_address2").innerHTML = text;

if (reg_city !== "" && reg_city.length <= 16 && reg_city.match(cityExp)) {
        text = "";
        } 
        
else {
    text = "Please enter a valid city for eg. Arlington";
    }
document.getElementById("error_city2").innerHTML = text;

if (reg_state !== "Select State"){
        text = "";
        } 
        
else {
    text = "Please Select any one option eg. Texas";
    }
document.getElementById("error_state_reg2").innerHTML = text;

if (reg_postal !== "" && reg_postal.match(numericExpression)){
        text = "";
        } 
        
else {
    text = "Please click on one of the options above.";
    }
document.getElementById("error_postal2").innerHTML = text;

if (reg_postal !== "" && reg_postal.match(numericExpression)){
        text = "";
        } 
        
else {
    text = "Please click on one of the options above.";
    }
document.getElementById("error_postal2").innerHTML = text;

if (reg_radio == true ){
        text = "";
        } 
        
else {
    text = "Please click on one of the options above.";
    }
document.getElementById("error_radio").innerHTML = text;

}

function myProfile() {

  var pro_nombre;
  var pro_apellido, pro_correo, pro_phone, pro_usrname,pro_pwd;

  var alphaExp = /^[a-zA-Z]+$/;
  var emailExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  var pwdExp = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
  var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;

  pro_nombre = document.getElementById("usr").value;
  pro_apellido = document.getElementById("lname").value;
  pro_correo = document.getElementById("email").value;
  pro_phone = document.getElementById("Telefono").value;
  pro_usrname = document.getElementById("username").value;
  pro_pwd = document.getElementById("login_pwd").value;

 if (pro_nombre !== "" && pro_nombre.length <= 32 && pro_nombre.match(alphaExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter a valid firstname for eg. Bob";
    }
document.getElementById("error_usr").innerHTML = text;


if (pro_apellido !== "" && pro_apellido.length <= 32 && pro_apellido.match(alphaExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter a valid lastname for eg. Williams";
    }
document.getElementById("error_lname").innerHTML = text;
  

if (pro_correo !== "" && pro_correo.length <= 32 && pro_correo.match(emailExp)) {
        text = "";
        } 
        else {
    text = "Please enter a valid email address for eg. somebody@example.com";
    }
document.getElementById("error_email").innerHTML = text;

if (pro_usrname !== "" && pro_usrname.length >= 8 && pro_usrname.length <=16 && pro_usrname.match(alphaExp) || pro_usrname !== "" && pro_usrname.length <= 64 && pro_usrname.match(emailExp)) {
        text = "";
        } 
        else {
    text = "Please enter valid username or registered email address";
    }
document.getElementById("error_username").innerHTML = text;

if (pro_pwd !== "" && pro_pwd.match(pwdExp)) {
        text = "";
        } 
        else {
    text = "Your password needs to be between 8 and 30 characters long, and contain one uppercase letter, one symbol, and a number";
    }
document.getElementById("error_pwd").innerHTML = text;

if (pro_phone !== "" && pro_phone.match(phoneno)) {
        text = "";
        } 
        else {
    text = "'Phone Number (Format:  xxxx-xxx-xxxx)";
    }
document.getElementById("error_phone").innerHTML = text;
}

