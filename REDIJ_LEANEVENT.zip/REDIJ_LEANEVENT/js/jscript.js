function myEvent() {

  var nombre,text,respo,lugar,fetcha,hora,valor;

  var alphaExp = /^[A-Za-z ]+$/;
  var addressExp = /^[a-zA-Z0-9\s,'-]*$/;
  var dateExp = /(0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])[- \/.](19|20)\d\d/;
  var timeExp = /^(0[0-9]|1[0-9]|2[0-3]|[0-9]):[0-5][0-9]$/;
  var valorExp = /^\$[0-9]+\.[0-9]{2}$/;


  nombre = document.getElementById("nombre").value;
  respo = document.getElementById("respo").value;
  lugar = document.getElementById("lugar").value;
  fetcha = document.getElementById("fetcha").value;
  hora = document.getElementById("hora").value;
  valor = document.getElementById("valor").value;

  if (nombre !== "" && nombre.match(alphaExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter valid event name eg. Event Name";
    }
document.getElementById("error_nombre").innerHTML = text;

if (respo !== "" && respo.match(alphaExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter valid name of person responsible eg. Responsible Name";
    }
document.getElementById("error_respo").innerHTML = text;

if (lugar !== "" && lugar.match(addressExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter valid address(should contain letters, numbers or spaces or ' or -)";
    }
document.getElementById("error_lugar").innerHTML = text;

if (fetcha !== "" && fetcha.match(dateExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter date in format MM/DD/YYYY";
    }
document.getElementById("error_fetcha").innerHTML = text;

if (hora !== "" && hora.match(timeExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter time in format HH:MM";
    }
document.getElementById("error_hora").innerHTML = text;

if (valor !== "" && valor.match(valorExp)) {
        text = "";
        } 
        
        else {
    text = "Please enter the amount in format : $000.00";
    }
document.getElementById("error_valor").innerHTML = text;

}

function fileUpload(){
  var x = document.createElement("INPUT");
  x.setAttribute("type", "file");
  document.body.appendChild(x);
}

